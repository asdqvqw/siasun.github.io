import{cO as i}from"./index-bf9c25ed.js";const t=()=>i&&/firefox/i.test(window.navigator.userAgent);export{t as i};
