import{N as a}from"./index-e9d9a390.js";const p=(e="")=>e.replace(/[|\\{}()[\]^$+*?.]/g,"\\$&").replace(/-/g,"\\x2d"),t=e=>a(e);export{t as c,p as e};
