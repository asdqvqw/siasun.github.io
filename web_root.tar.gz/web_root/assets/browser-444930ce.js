import{cO as i}from"./index-e9d9a390.js";const t=()=>i&&/firefox/i.test(window.navigator.userAgent);export{t as i};
