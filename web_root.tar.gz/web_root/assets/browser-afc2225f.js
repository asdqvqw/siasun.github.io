import{cO as i}from"./index-9f797bf0.js";const t=()=>i&&/firefox/i.test(window.navigator.userAgent);export{t as i};
