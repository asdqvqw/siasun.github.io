import{cO as i}from"./index-3842b3c8.js";const t=()=>i&&/firefox/i.test(window.navigator.userAgent);export{t as i};
