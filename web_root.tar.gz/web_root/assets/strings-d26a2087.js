import{N as a}from"./index-9f797bf0.js";const p=(e="")=>e.replace(/[|\\{}()[\]^$+*?.]/g,"\\$&").replace(/-/g,"\\x2d"),t=e=>a(e);export{t as c,p as e};
