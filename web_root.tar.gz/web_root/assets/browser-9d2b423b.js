import{cD as i}from"./index-9c50c20e.js";const t=()=>i&&/firefox/i.test(window.navigator.userAgent);export{t as i};
