import{cO as i}from"./index-1c344ead.js";const t=()=>i&&/firefox/i.test(window.navigator.userAgent);export{t as i};
