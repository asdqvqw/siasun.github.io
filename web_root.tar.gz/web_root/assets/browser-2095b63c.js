import{cO as i}from"./index-86487876.js";const t=()=>i&&/firefox/i.test(window.navigator.userAgent);export{t as i};
