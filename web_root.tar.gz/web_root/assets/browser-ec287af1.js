import{cO as i}from"./index-550ea9bd.js";const t=()=>i&&/firefox/i.test(window.navigator.userAgent);export{t as i};
