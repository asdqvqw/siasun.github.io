import{cO as i}from"./index-bef82f0e.js";const t=()=>i&&/firefox/i.test(window.navigator.userAgent);export{t as i};
