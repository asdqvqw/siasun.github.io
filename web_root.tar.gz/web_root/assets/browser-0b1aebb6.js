import{cO as i}from"./index-8ef3b182.js";const t=()=>i&&/firefox/i.test(window.navigator.userAgent);export{t as i};
